<?php
require_once __DIR__ . '/../config/auth.php';
requireLogin();

$id = $_GET['id'] ?? null;
if ($id) {
    $stmt = $pdo->prepare("DELETE FROM news WHERE id = ?");
    $stmt->execute([$id]);
}
header('Location: index.php');
exit;
