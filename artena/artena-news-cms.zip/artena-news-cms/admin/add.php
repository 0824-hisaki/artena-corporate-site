<?php
require_once __DIR__ . '/../config/auth.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("INSERT INTO news (title, body, published_date) VALUES (?, ?, ?)");
    $stmt->execute([
        $_POST['title'],
        $_POST['body'],
        $_POST['published_date'],
    ]);
}
header('Location: index.php');
exit;
