<?php
require_once __DIR__ . '/../config/auth.php';
requireLogin();

$stmt = $pdo->query("SELECT * FROM news ORDER BY published_date DESC, id DESC");
$newsList = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>お知らせ管理 | アルテナ株式会社</title>
<link rel="stylesheet" href="../css/site.css">
</head>
<body>
<div class="container">
    <h1>お知らせ管理</h1>
    <p>
        ようこそ、<?= htmlspecialchars(currentAdminName()) ?>さん
        <a href="logout.php">(ログアウト)</a>
        ｜ <a href="../news.php" target="_blank">公開ページを見る</a>
    </p>

    <h2>新規お知らせを追加</h2>
    <form method="post" action="add.php">
        <input type="date" name="published_date" value="<?= date('Y-m-d') ?>" required>
        <input type="text" name="title" placeholder="タイトル" required>
        <textarea name="body" placeholder="本文" required rows="5"></textarea>
        <button type="submit">追加</button>
    </form>

    <h2>お知らせ一覧</h2>
    <table>
        <tr><th>日付</th><th>タイトル</th><th>操作</th></tr>
        <?php foreach ($newsList as $n): ?>
        <tr>
            <td><?= htmlspecialchars($n['published_date']) ?></td>
            <td><?= htmlspecialchars($n['title']) ?></td>
            <td class="actions">
                <a class="btn" href="edit.php?id=<?= $n['id'] ?>">編集</a>
                <a class="btn btn-delete" href="delete.php?id=<?= $n['id'] ?>"
                   onclick="return confirm('削除してよろしいですか？');">削除</a>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($newsList)): ?>
        <tr><td colspan="3">お知らせはまだありません</td></tr>
        <?php endif; ?>
    </table>
</div>
</body>
</html>
