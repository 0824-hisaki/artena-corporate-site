<?php
require_once __DIR__ . '/../config/auth.php';
requireLogin();

$id = $_GET['id'] ?? $_POST['id'] ?? null;
if (!$id) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("UPDATE news SET title = ?, body = ?, published_date = ? WHERE id = ?");
    $stmt->execute([
        $_POST['title'],
        $_POST['body'],
        $_POST['published_date'],
        $id,
    ]);
    header('Location: index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM news WHERE id = ?");
$stmt->execute([$id]);
$news = $stmt->fetch();

if (!$news) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>お知らせを編集 | アルテナ株式会社</title>
<link rel="stylesheet" href="../css/site.css">
</head>
<body>
<div class="container">
    <h1>お知らせを編集</h1>
    <form method="post" action="edit.php">
        <input type="hidden" name="id" value="<?= $news['id'] ?>">
        <input type="date" name="published_date" value="<?= htmlspecialchars($news['published_date']) ?>" required>
        <input type="text" name="title" value="<?= htmlspecialchars($news['title']) ?>" required>
        <textarea name="body" required rows="6"><?= htmlspecialchars($news['body']) ?></textarea>
        <button type="submit">更新</button>
        <a class="btn" href="index.php">キャンセル</a>
    </form>
</div>
</body>
</html>
